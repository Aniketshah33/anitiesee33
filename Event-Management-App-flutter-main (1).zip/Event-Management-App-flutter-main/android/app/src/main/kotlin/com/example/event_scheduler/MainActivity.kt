package com.example.event_scheduler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
